package com.app.osege.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class MainSecondActivity : AppCompatActivity() {
    private val webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_second)
        val webView = findViewById<WebView>(R.id.osege)
        webView?.webViewClient = WebViewClient()
        webView?.loadUrl("https://www.ventusky.com/")
        val webSettings = webView?.settings
        webSettings?.javaScriptEnabled = true

    }

    override fun onBackPressed() {
        if (webView!!.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
